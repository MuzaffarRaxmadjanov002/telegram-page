

const inputWord = document.querySelector("#Word");
const btn = document.querySelector("#btn");
const h1text = document.querySelector("h1");
const btn2 = document.querySelector("#btn2");
const btn3 = document.querySelector('#btn3');
let Delete = document.querySelector(".delete");



Delete.addEventListener("click",() =>{
    inputWord.value  = "";
})

// o'zbekcha tarjima


btn2.addEventListener ("click", () => {
  switch (inputWord.value.toLowerCase()) {

    case "cat":
      h1text.innerHTML = "Mushuk";
      break;

    case "кошка":
        h1text.innerHTML = "Mushuk";
        break;
      
    case "car":
      h1text.innerHTML = "Moshina";
      break;

    case "машина":
        h1text.innerHTML = "Moshina";
        break;

    case "phone":
        h1text.innerHTML = "Telefon";
        break; 

    case "телефон":
        h1text.innerHTML = "Telefon"
        break;

    case "ball":
        h1text.innerHTML = "Koptok";
        break;

    case "мяч":
        h1text.innerHTML = "Koptok";
        break;

    case "курица":
         h1text.innerHTML = "Tovuq";
         break;
     
    case "chicken":
        h1text.innerHTML = "Tovuq";
        break;   
        
    case "cow":
        h1text.innerHTML = "Sigir";
        break;
        
    case "корова":
        h1text.innerHTML = "Sigir";
        break; 
        
    case "computer":
        h1text.innerHTML = "Kompyuter";
        break; 

    case "компьютер":
        h1text.innerHTML = "Kompyuter";
        break;
        
    case "coder":
        h1text.innerHTML = "Dasturchi";
        break;  
        
    case "программист":
        h1text.innerHTML = "Dasturchi";
        break;

    case "women":
        h1text.innerHTML = "Ayol";
        break;

    case "men":
        h1text.innerHTML = "Erkak";
        break;
   
    case "Женщины":
        h1text.innerHTML = "Ayol";
        break;

    case "мужской":
        h1text.innerHTML = "Erkak";
        break;

    case "keyboard":
        h1text.innerHTML = "Klavitura";
        break;

    case "клавиатура":
        h1text.innerHTML = "Klavitura";
        break;
     
    default:
      h1text.innerHTML = "Bunday soz mavjud  emas !";
  }


  inputWord.addEventListener('click', () => {
    inputWord.value = "";
})

});

//  O'zbekcha tarjima



//  Inglizcha tarjima




btn.addEventListener ("click", () => {
  switch (inputWord.value.toLowerCase()) {



    case "mushuk":
      h1text.innerHTML = "cat , kitty";
      break;
     
    case "кошка":
        h1text.innerHTML = "Cat";
        break;

    
    case "mashina":
      h1text.innerHTML = "Car , transport";
      break;

    case "машина":
        h1text.innerHTML = "Car , transport"
    
    case "telefon":
        h1text.innerHTML = "Phone";
        break;
    
    case "телефон":
        h1text.innerHTML = "Phone";
        break;

    case "koptok":
        h1text.innerHTML = "Ball";
        break;  
        
    case "мяч":
        h1text.innerHTML = "Ball";
        break;
    
    case "sichqon":
        h1text.innerHTML = "Mouse";
        break; 

    case "мышь":
        h1text.innerHTML = "Mouse";
        break;

    case "курица":
        h1text.innerHTML = "chicken";
        break;    
    
    case "tovuq":
        h1text.innerHTML = "Chicken";
        break; 
        
    case "sigir":
        h1text.innerHTML = "Cow";
        break;    

    case "корова":
        h1text.innerHTML = "Cow";
        break;
        
    case "kompyuter":
        h1text.innerHTML = "Computer";
        break; 
        
    case "компьютер":
        h1text.innerHTML = "Computer";
        break; 

    case "dasturchi":
        h1text.innerHTML = "Coder";
        break;

    case "программист":
        h1text.innerHTML = "Coder"
   
    case "ayol":
        h1text.innerHTML = "Women";
        break;

    case "девушка":
        h1text.innerHTML = "Young women";
        break;

    case "Женщины":
        h1text.innerHTML = "Women";
        break;

    case "erkak":
        h1text.innerHTML = "Men";
        break;

    case "мужской":
        h1text.innerHTML = "Men";
        break;








    default:
      h1text.innerHTML = "Bunday soz mavjud  emas !";


  }
  
  


  inputWord.addEventListener('click', () => {
    inputWord.value = "";
})

});

//   Inglizcha tarjima




//  Ruscha tarjima


btn3.addEventListener ("click",() => {
    switch (inputWord.value.toLowerCase()) {



 case "tovuq":
    h1text.innerHTML = "курица";
    break; 
 
case "chicken":
    h1text.innerHTML = "курица";
    break;
    
case "sigir":
    h1text.innerHTML = "корова";
    break;

case "cow":
    h1text.innerHTML = "корова";
    break;
 
case "computer":
    h1text.innerHTML = "компьютер"
    break;
    
case "kompyuter":
    h1text.innerHTML = "компьютер";
    break;    
    
case "ayol":
        h1text.innerHTML = "девушка";
        break;

case "erkak":
        h1text.innerHTML = "мужской";
        break;

case "women":
    h1text.innerHTML = "Женщины";
    break;

case "men":
    h1text.innerHTML = "мужской";
    break;

case "kuchuk":
        h1text.innerHTML = "собака";
        break;

case "dog":
    h1text.innerHTML = "собака";
    break;

case "mushuk":
    h1text.innerHTML = "кошка";
    break;

case "cat":
    h1text.innerHTML = "кошка";
    break;

case "moshina":
    h1text.innerHTML = "машина";
    break;

case "car":
    h1text.innerHTML = "машина";
    break;

case "telefon":
        h1text.innerHTML = "телефон";
        break;

case "phone":
    h1text.innerHTML = "телефон";
    break;

case "internet":
    h1text.innerHTML = "Интернет";
    break;

case "klavitura":
        h1text.innerHTML = "клавиатура";
        break;

case "keyboard":
    h1text.innerHTML = "клавиатура";
    break;




 default:
      h1text.innerHTML = "Bunday soz mavjud  emas !";
    }   
});

//  Ruscha tarjima