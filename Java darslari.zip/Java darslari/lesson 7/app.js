// sort --> tartiblash ,ketma ketli..

// let numbers = [9,5,2,6,1];
// let sortedNumbers = numbers.sort(); //.sort() => metod
// console.log (sortedNumbers);


// letters
// let letters = ["f", "p", "a", "i", "y", "g", "b", "w", "s"];
// let sortedLetters = letters.sort(); //.sort() => metod
// console.log (sortedLetters);


//complex
// let twoNumbers = [44,33,3,11,43,44,85,2,12,105];
// let twoSortedNumbers = twoNumbers.sort((a,b)=>a-b);
// // let twoSortednumbers = twoNumbers.sort((a,b)=>b-a);
// console.log(twoSortedNumbers);

 //words
//  let words = ["banana", "Apple","Abble", "Peach", "Kivi", "Aprcot", "grape"];
//  let sortedWords = words.sort();
//  console.log(sortedWords)

//find the lergest
// let randomNumbers = [6,4,2,10,3,9];
// let sortedRandomNumbers = randomNumbers. sort((a,b) => b-a);
// console.log(sortedRandomNumbers [0]);

// console.log(Math.max (6,4,2,10,18, 78,3,9));
// console.log(Math.min (6,4,2,10,18,34,3,9));



//Filter --> saralab olish

//numbers


// let  fNumbers = [5,3,8,10,12,9,6];
// // let largerThan6 = fNumbers.filter(t => t>6);
// // // // t =. bu har bir arrayni elementga nom berish
// // console.log(largerThan6)

// let largerThan3 = fNumbers.filter(t => t % 2==0);
// console.log(largerThan3) 

//task
// let justNumbers = [-4,2,7,9,0,-1,-2,-20,-3.6];
// let negativeNumbers = justNumbers.filter(n=> n<0).sort((a,b) => a-b);
// console.log(negativeNumbers)

//words
// let fwords = ["Johnbek","adamsva","Smithbek","William"];
// let withBek = fwords.filter(k=> k.includes("va"));
// console.log(withBek)
//includes--




//complex
// let investors = [
//     {name: "Elon Musk", investment: 5000},
//     {name: "Jeff Bezos", investment: 2000},
//     {name: "Alisher Navoi", investment: 6000},
//     {name: "Uern Buffet", investment: 3000},
// ];
// let investment3000 = investors.filter(j => j.investment>=3000);
// console.log(investment3000)

//task
// let investors2= [
//     {name: "Elon Musk", investment: 5000, cars: ["Captiva","Tico"]},
//     {name: "Jeff Bezos", investment: 2000 , cars: ["Captiva","damas", "fura"]},
//     {name: "Alisher Navoi", investment: 6000, cars: ["gentra","malibu"]},
//     {name: "Uern Buffet", investment: 3000, cars: ["opel","Lambo"]},
// ];
// let investment3000 = investors2.filter(j => j.cars.length<3);
// console.log(investment3000)






// let people= [
//     {name: "Alisher Qodirov", millioner: 12000 },
//     {name: "Ahmadjon Alimardonov", millioner: 16000},
//     {name: "Tursunali Toxsaninov", millioner: 23000},
//     {name: "Abdumanop Burxanov", millioner:40000},
//     {name: "Tursunxon", millioner:10000},
//     {name: "Abduraxmon", millioner:15000},
//     {name: "Axadjon Tursunaliyev", millioner:50000},
//     {name: "Baxodir Burxanov", millioner:130000},
//     {name: "Asadbek Xudayberdiyev", millioner:32000},
//     {name: "Saxobiddin Tursunov", millioner:5000},
// ];
// let people15000 = people.filter(n=> n.millioner >=15000);
// let peopleSort = people.sort(m=> m.millioner >15000);
// console.log(people15000,peopleSort );



// words
// let fwords = ["Aliyev","Otamirzayeva","Bekmirzayev","Xojayeva","Tursunov","Polatova","Alixajanov","Abdullayeva","Rahmonjanov","Turg'unpolatov","Axmadjanova","Jo'rayeva","Muhammadaliyeva","Abdurahimova","Baxoviddinov","Toshpolatovaa","Abdumutalliyev",'Yunusova','Isoqjanova',"Dadaxanov",'Botirova'];
// let withBek = fwords.filter(k=> k.includes("va")).sort();
// // let mithBek = fwords.filter(f=> f.includes("ov")).sort();
// console.log(withBek);




// [[Prototype]]
// : 
// Array(0)
// at
// : 
// ƒ at()
// concat
// : 
// ƒ concat()
// constructor
// : 
// ƒ Array()
// copyWithin
// : 
// ƒ copyWithin()
// entries
// : 
// ƒ entries()
// every
// : 
// ƒ every()
// fill
// : 
// ƒ fill()
// filter
// : 
// ƒ filter()
// find
// : 
// ƒ find()
// findIndex
// : 
// ƒ findIndex()
// findLast
// : 
// ƒ findLast()
// findLastIndex
// : 
// ƒ findLastIndex()
// flat
// : 
// ƒ flat()
// flatMap
// : 
// ƒ flatMap()
// forEach
// : 
// ƒ forEach()
// includes
// : 
// ƒ includes()
// indexOf
// : 
// ƒ indexOf()
// join
// : 
// ƒ join()
// keys
// : 
// ƒ keys()
// lastIndexOf
// : 
// ƒ lastIndexOf()
// length
// : 
// 0
// map
// : 
// ƒ map()
// pop
// : 
// ƒ pop()
// push
// : 
// ƒ push()
// reduce
// : 
// ƒ reduce()
// reduceRight
// : 
// ƒ reduceRight()
// reverse
// : 
// ƒ reverse()
// shift
// : 
// ƒ shift()
// slice
// : 
// ƒ slice()
// some
// : 
// ƒ some()
// sort
// : 
// ƒ sort()
// splice
// : 
// ƒ splice()
// toLocaleString
// : 
// ƒ toLocaleString()
// toReversed
// : 
// ƒ toReversed()
// toSorted
// : 
// ƒ toSorted()
// toSpliced
// : 
// ƒ toSpliced()
// toString
// : 
// ƒ toString()
// unshift
// : 
// ƒ unshift()
// values
// : 
// ƒ values()
// with
// : 
// ƒ with()
// Symbol(Symbol.iterator)
// : 
// ƒ values()
// Symbol(Symbol.unscopables)
// : 
// {at: true, copyWithin: true, entries: true, fill: true, find: true, …}
// [[Prototype]]
// : 
// Object