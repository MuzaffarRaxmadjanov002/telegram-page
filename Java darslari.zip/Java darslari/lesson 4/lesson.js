let menu = document.querySelector("#menu");
let remove = document.querySelector("#remove");
let page = document.querySelector(".menu-page");
let item1 = document.querySelector(".item1");
let item2 = document.querySelector(".item2");
let item3 = document.querySelector(".item3");
let item4 = document.querySelector(".item4");
let banner2 = document.querySelector(".banner-item2");
let banner1 =document.querySelector(".banner-item1");
let banner3 = document.querySelector(".banner-item3");
let banner4 = document.querySelector(".banner-item4");

menu.addEventListener("click",() => {
    page.style = "display:block;";
    remove.style = "display:block;";
       menu.style ="display:none;;"
    
})
remove.addEventListener("click",()=>{
     remove.style = "display:none;";
     menu.style ="display:block;;"
      page.style = "display:none;";
})



item1.addEventListener("click",()=>{
    banner2.style="display:none;";
    banner1.style="display:block;";
    banner3.style="display:none;";
    banner4.style="display:none;";
})
item2.addEventListener("click",()=>{
    banner2.style="display:block;";
    banner1.style="display:none;";
    banner3.style="display:none;";
    banner4.style="display:none;";
})
item3.addEventListener("click",()=>{
    banner2.style="display:none;";
    banner1.style="display:none;";
    banner3.style="display:block;";
    banner4.style="display:none;";
})
item4.addEventListener("click",()=>{
    banner2.style="display:none;";
    banner1.style="display:none;";
    banner3.style="display:none;";
    banner4.style="display:block;";
})