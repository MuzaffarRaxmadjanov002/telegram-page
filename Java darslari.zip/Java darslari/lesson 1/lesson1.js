let sidebar = document.querySelector(".sidebar");
let button = document.querySelector("#btn");
let button1 = document.querySelector("#btn1");
let chiqish = document.querySelector("#chiqish");
let kirish = document.querySelector("#kirish");

button.addEventListener('click',() =>{
    sidebar.style = "margin-top:-350px;";
})

button1.addEventListener('click',() =>{
    sidebar.style = "margin-top:0px;";
})

chiqish.addEventListener('click',() =>{
    kirish.style = "display:block;";
    chiqish.style = "display:none;";
})

kirish.addEventListener('click',() =>{
    kirish.style = "display:none;";
    chiqish.style = "display:block;";
})