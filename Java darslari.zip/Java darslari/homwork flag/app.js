const salom = document.querySelector('#salom');
const reset = document.querySelector("#reset");
const h1 = document.querySelector("h1");

salom.addEventListener("click",()=>{
    reset.style = "display:block";

 
    
    

    //  h1.value = "xato kiritildi";
} )

reset.addEventListener("click",()=>{
    salom.style = "display:none";
    salom.style = "display:block";
});