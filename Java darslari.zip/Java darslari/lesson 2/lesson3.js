let sidebar = document.querySelector(".sidebar");
let button = document.querySelector("#btn");
let button1 = document.querySelector("#btn1");
let chiqish1 = document.querySelector("#chiqish");
let kirish1= document.querySelector("#kirish")

button.addEventListener('click',() =>{
    sidebar.style = "margin-left: -920px;";
   
   

})

button1.addEventListener('click',() =>{
    sidebar.style = "margin-left: 0px;";
   
    
})

chiqish1.addEventListener("click",()=> {
     kirish1.style= "display:block;";
    chiqish1.style= "display:none;";

})
kirish1.addEventListener("click",()=> {
     kirish1.style= "display:none;";
    chiqish1.style= "display: block;";

})