// let x = -15
// if (x>0){
//     console.log("Musbat");

// }else{
//     console.log("Manfiy")
// }

// let y = 7 
// let x = 8
// == qiymatni tekshiradi
// ===data typeni va qiymatni tekshiradi
// >=teng yoki katta <= teng yoki kichik

// console.log(y>x);

// let x = prompt("Kodni kiriting")

// if(x == 571632){
//     console.log("saytimizga hush kelibsiz");

// }else{
//     consol.log("kodn natog'ri kiritilgan")
// }

// let x = 21

// if(x >= 10 && x <=20){
//     console.log("ha");
// }else{
//     console.log("yoq");
// }

// let y = 24

// if(y>15||y<25||y===23){
//     console.log("ha")
// }else{
//     console.log("yoq")
// }

// &&"va" barcha shart tru bolsa keyin tru qaytadi "yoki" bitta shart tru bolsa yetadi

