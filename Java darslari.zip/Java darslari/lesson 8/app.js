//some...
//numbers

// let sNumber = [3,4,1,2,0,7,2,5];
// let numbers = sNumber.some(h=>h=>10);
// console.log(numbers);

//words
// let sWords = ["joe","stveen","JOHN"];
// let dWords = sWords.some(t=t=="stveen");
// console.log(dWords);

//letters
// let sLetter= ["i","l",'k','m'];
// let dLetters = sLetter.some(z=> z=="k");
// console.log(dLetters);

//complex
// let student=[
//     {name: 'bexruz', age: 3},
//     {name: 'Abdullo', age: 18},
//     {name: 'azizbek', age: 15},
// ]
// let hasanboy= student.some(d=>d.age >=18);
// console.log(hasanboy);

//Evry ... bittasi hato bolsa ham natog'ri beradi

// let sNumbers=[15,12,20,7,10];
// let hastnumber=sNumber.every(u=>u>10);
// console.log(hastnumber);
// Numbers & words---kodi shu usulda ishlatiladi

// Find
// Numbers
// let fNumbers=[3,5,6,12,2];
// let hest = fNumbers.find(w=>w>3);
// console.log(hest);


//complex
// let fAdmin =[
//     {username: "Sanith", role:"Page", age: "18"},
//     {username: "Usi", role:"observer", age: "29"},
//     {username: "doe", role: "Server", age: "17"},
// ]
// let madmin = fAdmin.find(u=>u.age >18);
// console.log(madmin);


//Fill
//numbers
//let fillNumbers = [6,7,8,9,10,3,2];
//let changeNumbers = fillNumbers.fill("",0,4);
//console.log(changeNumbers);