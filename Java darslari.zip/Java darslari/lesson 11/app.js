//              SPLIT
//        SPLIT => bo'lish, bo'laklash
// let word = "salom".split("")
// console.log(word);
//        /SPREAD OPERATOR/ => split bilan bir hil
// let word2 = [..."hello"];
// console.log(word2);


//              SPLICE
//           splice qilingan element arraydan butkul yo'qoladi
// let users = ["Steve", "Smith", "John", "Doe", "Bill"];
// let twouser = users.splice( 1,3)//2=> boshlanish === 3=> tugash
// console.log(twouser);
// console.log(users);


//              SLICE
// let cars = ["Damas", "Tico", "Nexia", "Matiz", "Spark"];
// let threeElement = cars.slice(0, 3);
// console.log(threeElement);
// console.log(cars);





//                REDUCE => qisqartirmoq
// let numbers = [5, 9, 1,8];
// let sum = numbers.reduce((a, b) => a + b , 0 );
// console.log(sum);



//         MAP
// let nums = [5, 3, 2, 9, 10];
// let expo = nums.map(n => n * n);
// console.log(expo);

// let w = ["Damas", "Tico", "Nexia", "Matiz", "Spark"];
// let n = w.map(c => "Dabdala Gm" + c)
// let t = w.map(c => c.replace(/k/g, ""));
// console.log(n);
// console.log(t);


// let k = [9, 4,];
// let l =k.map(n => n * n * n);
// let m =l.reduce((a, b) => a +b);
// console.log(m);