const main = document.querySelector('.main');
const fromInput = document.querySelector('.from-input');
const fromSubmit = document.querySelector('.from-submit');
const endH1 = document.querySelector('.end-h1');
const image = document.querySelector('.end-img');
const form = document.querySelector(".form-item");
const homeProduct = document.querySelector(".home-product");







fromSubmit.addEventListener ("click", () => {
    switch (fromInput.value.toLowerCase()) {
  
      case "amerika":
        endH1.innerHTML = "Amerika bayrog'i";
        image.src = "amerika.jpg";
   
        break;
      
    case "rossiya":
        endH1.innerHTML = "Rossiya bayrog'i"  ;
        image.src = "rossiya.jpeg";
        break;  

    case "uzbekistan":
      endH1.innerHTML = "O'zbekiston Bayrog'i";
      image.src = "uzb.jpeg";
      break;
        
  

        
      default:
        endH1.innerHTML = "Bunday davlat mavjud  emas !";
    }
});

// fromInput.addEventListener('click',() =>{
//     image.style = "display:none";
//     endH1.style = "display:none";
  

    
// })

// homeProduct.addEventListener('click',() =>{
//     image.style = "display:inline-block";
//     endH1.style = "display:inline-block";
// })

// form.addEventListener('submit', (event)=>{
//     event.preventDefault();
//     let fromInput = fromSubmit.value

//     if(fromInput  === "1234"){
//         boshqa.style = "display:block;";
//        screenH1.style = "display:none;";
//        main.style = "display:none;";
//     //    boshqa.style = "display:none"
       
       
//     }
//     else{
//         screenH1.style = "display:block"
//            box.style = "display:none;";
//            container.style = "display:none;";
//     }


    
   
//     fromInput.value = ""
// })

// fromSubmit.addEventListener("click",()=>{
//     screenH1.style = "display:block;";
//     boshqa.style = "display:none;";
    
    
//  })
