// min 
// let numbers = [2,4,6,8,-1,0,6,9,]

// let minimum = Math.max(9,2,5,8,1, -1);
// let lowes = Math.min(...numbers)
// console.log(lowes);
// console.log(minimum);

// max
// let maximum = Math.max(9,2,5,10,8,1);
// let highest= Math.max(...numbers);
// console.log(maximum);
// console.log(highest);

// //pow
// let expo = Math.pow(2,3);
// console.log(expo);

// sqrt
// let squareRoot = Math.sqrt(81);
// console.log(squareRoot);

// floor
// let fn = Math.floor(4.556546768);
// console.log(fn);

// round
// let rN = Math.round(3.45);
// console.log(rN);

// ceil
// let cN = Math.ceil(-2,99);
// console.log(cN);

// random
// let students= ["Asadbek","Qobiljon","Muzaffar","Axadhon","Abduazm"];
// let random = Math.floor(Math.random()*10);
// console.log (students[random]);

// pi
// let circleLenght = 12 * Math.PI;
// console.log(circleLenght);

// abs
// let aN = Math.abs(-5);
// console.log(aN);

// perseInt
// let pIn = parseInt("44kj3Hhgd4fyd,ityglujvi");
// console.log(pIn);

// parseFloat
// let pFl = parseFloat("123.144t5hi6")
// console.log(pFl);

// toFixed
// let tF = 34.39242.toFixed(2);
// console.log(tF)