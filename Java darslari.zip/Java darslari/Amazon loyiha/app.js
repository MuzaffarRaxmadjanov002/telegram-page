let qidiruv = document.querySelector("#qidiruv");
let oddiy = document.querySelector(".oddiy");
let navbarInput = document.querySelector(".navbar-input")






qidiruv.addEventListener("click",() => {
    oddiy.style = "background-color:rgba(0, 0, 0, 0.241);";
    

    

    
})
oddiy.addEventListener("click",() => {
    oddiy.style = "background-color: none;";
    navbarInput.style  = "box-shadow:none";

    
})
navbarInput.addEventListener("click",() => {
    navbarInput.style = "border:3px solid yellow;";

    
})
$('.carousel').carousel()