const form = document.querySelector('.form');
const inputNumber = document.querySelector('.input_number');
const box = document.querySelector(".container");
const  inputValue = document.querySelector('#input1')
const text = document.querySelector(".text")
const main = document.querySelector(".from-item");
const logAut = document.querySelector('.asosiy-box__button')

 logAut.addEventListener("click",()=>{
    main.style = "display:block;";
    box.style = "display:none;"
    
 })



form.addEventListener('submit', (event)=>{
    event.preventDefault();
    let inputValue = inputNumber.value

    if(inputValue  === "1234"){
      box.style = "display:block;";
       text.style = "display:none;";
       main.style = "display:none;";
      
       
    }
    else{
        text.style = "display:block";
           box.style = "display:none;";
           container.style = "display:none;";
    }


    
   
    inputNumber.value = ""
})