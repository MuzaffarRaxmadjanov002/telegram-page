const form = document.querySelector('.form');
const inputNumber = document.querySelector('.input_number');
const root = document.querySelector('.root');
const desk = document.querySelector('.desk');
const image = document.querySelector('.image')
const music = document.querySelector('music_maymun')

form.addEventListener('submit', (event)=>{
    event.preventDefault();
    let inputValue = inputNumber.value

    if(inputValue  === ""){
        alert("yilni kiriting")
        return
    }

    
    if(inputValue < 1900){
        alert("Kattaroq yil kiriting")
        return;
        
    }

    //audio chiqarish 

//     let play = document.getElementById("play"); 
//     function playMusic() {
//     let audio = new Audio("mol.mp3");
//     audio.play()
//    }

//     play.addEventListener("click", playMusic);


//Javascript
//play sound on 

// function playSound(audioName,loop) {
//     let audio = new Audio(audioName);
//     audio.loop = loop
//     audio.play();
// }
// playSound("mol.mp3")




    let muchal = inputValue % 12

    if(muchal % 12 === 0){
        desk.innerHTML = "Maymun"
        image.src = "img/1.jpg"
        music.play("audio/maymun.mp3");
    }else if( muchal === 1 ){
        desk.innerHTML = "Tovuq"
        image.src = "img/2.jpg"
        music.play("audio/chick.mp3");
    }else if( muchal === 2 ){
        desk.innerHTML = "It"
        image.src = "img/3.jpg"
    }else if( muchal === 3 ){
        desk.innerHTML = "To'ng'iz"
        image.src = "img/4.jpg"
    }else if( muchal === 4 ){
        desk.innerHTML = "Sichqon"
        image.src = "img/5.jpg"
        
    }else if( muchal === 5 ){
        desk.innerHTML = "Sigir"
        image.src = "img/6.jpg"
    }else if( muchal === 6 ){
        desk.innerHTML = "Yo'lbars"
        image.src = "img/7.jpg"
    }else if( muchal === 7 ){
        desk.innerHTML = "Quyon"
        image.src = "img/8.jpg"
    }else if( muchal === 8 ){
        desk.innerHTML = "Baliq"
        image.src = "img/9.jpg"
    }else if( muchal === 9 ){
        desk.innerHTML = "Ilon"
        image.src = "img/10.jpg"
    }else if( muchal === 10 ){
        desk.innerHTML = "Ot"
        image.src = "img/11.jpg"
    }else if( muchal === 11 ){
        desk.innerHTML = "Qo'y"
        image.src = "img/12.jpg"
    }

    inputNumber.value = ""
})