
// 1 malumot turi 
// var firstname="Bobur";
// var surname="Sodiqov";
// var uf="savdo";
// console.log(firstname + " "+surname+ " " + uf + " "+"Markaz haqida malumot berildi");

 //malumot turi =>about 2=>   

// var country="o'zbekiston";
// var company="GM";
// console.log( country+"da" + " " + company+ " "+ "yagona mashina ishlab chiqarish zavodi")

// 2-ma'lumot turi=>number=>raqam

// var a=20;
// var b=30;
// console.log(a+b+ " ta jami oquvchilar soni")

//  var a=2;
//  var b=4;
//  var c=20;
//  console.log(a+b*c+ "ta jami oquchilar soni")

// var a=2;
// var b=4;
// var c=20;
// console.log(a+b+c+"")

//3-malumot turi=>boolean=> togri yoki notog'ri
//true----ha
//fols----yoq

//malumot turi=>arry--toplam saf

var names=["Baxodir", "Asadbek", "Shaxboz"]
var name=[4,5,6,7,8,]
// console.log(name);
console.log(names[2])
console.log(names.length)    

// length--toplami ichidagi elementlarni hisoblab beradi

//5-malumot turi =>underfiend=>malumot yoqligi
// var user =undefined;
// console.log(user);

//undefined--malumot yoq

//let raqamlar =[8,10,4,20,3,7]
//console.log([10]);

//var firstname = 45;
//var lastname = 6;
//var number = 56;
//console.log(firstname+lastname/number)

//var firstname ="namangan"
//var lastname ="coca cola"
//console.log(firstname+"da" +lastname + "zavodi bor")


